"""Validate Android observations of local generated frame documents."""

import argparse
import hashlib
import json
import os
from pathlib import Path

ROOT = Path(__file__).resolve().parent
POLICY = "default-src 'none'; script-src 'self' 'unsafe-inline'; frame-src 'self'; worker-src 'none'; base-uri 'none'"
KINDS = ("same", "blob", "data")


def document_identity(origin, kind):
    expected_origin = "null" if kind == "data" else origin
    return {"name": kind, "protocol": ("https" if kind == "same" else kind) + ":",
            "origin": expected_origin, "messageOrigin": expected_origin}


def observation_failures(origin, mode, kind, page):
    failures = []
    starts = page.get("starts")
    workers = page.get("workers")
    violations = page.get("frameViolations")
    if not all(isinstance(values, list) for values in (starts, workers, violations)):
        return ["the frame observation is incomplete"]
    if not starts:
        if mode == "control" or kind == "same":
            failures.append("the positive document control did not report")
        expected = {"directive": "frame-src", "disposition": "enforce", "scheme": kind, "trusted": True}
        observed = violations == [expected] or (kind == "data" and violations == [dict(expected, scheme=None)])
        if not observed:
            failures.append("an enforcing frame-src event was not observed")
        if workers or page.get("trace") != ["attach", "frame-violation", "detach"]:
            failures.append("the blocked frame observation sequence differs")
        return failures

    if mode == "guarded" and kind == "data":
        failures.append("the opaque document executed")
    if starts != [document_identity(origin, kind)]:
        failures.append("the executed document's URL scheme or origin differs")
    if violations:
        failures.append("the executed document also reports a frame refusal")
    expected_trace = ["attach", "ready"]
    if kind == "data":
        if workers:
            failures.append("the opaque document reported an unexpected worker")
    else:
        event = {"directive": "worker-src", "disposition": "enforce", "trusted": True,
                 "blockedURI": origin + "/worker.js"}
        expected_worker = {"messageOrigin": origin, "outcome": "message", "violations": []}
        if mode == "guarded":
            expected_worker.update(outcome="rejected", violations=[event])
        if workers != [expected_worker]:
            failures.append("the executed document's worker result differs")
        expected_trace.append("worker-result")
    if page.get("trace") != [*expected_trace, "detach"]:
        failures.append("the frame observation sequence differs")
    return failures


def classify(report, *, expect_retained_outcomes=False):
    failures = []
    run = report["run"]
    if report.get("complete") is not True or not all(report.get(key) for key in ("sdk", "release", "provider")):
        failures.append("native collection did not complete")
    samples = report.get("samples", {})
    if set(samples) != {"control", "guarded"}:
        failures.append("both fresh profiles are required")
    for mode in ("control", "guarded"):
        sample = samples.get(mode, {})
        origin = f"https://mp-{run}-{mode}.invalid"
        if (sample.get("profile") != f"local-document-frames-{run}-{mode}" or sample.get("created") is not True
                or sample.get("cookieDeny") is not True):
            failures.append(f"{mode}: selected profile or cookie deny differs")
        frames = sample.get("frames", {})
        if set(frames) != set(KINDS):
            failures.append(f"{mode}: frame samples differ")
        worker_receipts = {}
        for kind in KINDS:
            frame = frames.get(kind, {})
            page = frame.get("page", {})
            entry = f"/entry/{kind}"
            url = origin + entry
            if frame.get("parentUrl") != url or page.get("parentUrl") != url:
                failures.append(f"{mode}/{kind}: the separate parent document differs")
            if frame.get("policy") != (POLICY if mode == "guarded" else ""):
                failures.append(f"{mode}/{kind}: parent response policy differs")
            requests = frame.get("requests", [])
            expected = {entry, "/probe.js"}
            if kind == "same":
                expected.add("/same-frame")
            worker_receipts[kind] = requests.count("/worker.js")
            allowed = expected | {"/worker.js"} if mode == "control" and kind != "data" else expected
            if (not expected <= set(requests) <= allowed or requests.count(entry) != 1
                    or requests.count("/same-frame") != int(kind == "same")):
                failures.append(f"{mode}/{kind}: loader requests differ")
            failures.extend(f"{mode}/{kind}: {issue}" for issue in observation_failures(origin, mode, kind, page))
            if expect_retained_outcomes and mode == "guarded" and kind == "blob" and page.get("starts"):
                failures.append("guarded/blob: retained frame refusal differs")
        if mode == "control":
            if not sum(worker_receipts.values()):
                failures.append("control: no worker script reached the native loader")
            if expect_retained_outcomes and worker_receipts != {"same": 1, "blob": 1, "data": 0}:
                failures.append("control: retained worker receipt counts differ")
    return failures


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def source_fingerprints():
    wrapper = ROOT.parent.parent / "android-origin-probe"
    android = ROOT / "android"
    files = [
        ROOT / "check.py", ROOT / "run_probe.py", ROOT.parent / "runner.py",
        wrapper / "gradlew", wrapper / "gradle/wrapper/gradle-wrapper.jar",
        wrapper / "gradle/wrapper/gradle-wrapper.properties",
        android / "settings.gradle", android / "build.gradle", android / "gradle.properties",
        android / "app/build.gradle", android / "app/src/main/AndroidManifest.xml",
    ]
    files.extend((ROOT / "assets").glob("*.js"))
    files.extend((android / "app/src/main/java").rglob("*.java"))
    return {Path(os.path.relpath(path, ROOT)).as_posix(): sha(path) for path in sorted(files)}


def describe(report):
    frames = report.get("samples", {}).get("guarded", {}).get("frames", {})
    return ", ".join(f"{kind}: {'executed' if frames[kind].get('page', {}).get('starts') else 'no document'}"
                     for kind in KINDS if kind in frames)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("report", type=Path)
    parser.add_argument("--expect-retained-outcomes", action="store_true",
                        help="Require blob refusal and one loader worker receipt per control worker frame")
    args = parser.parse_args()
    report = json.loads(args.report.read_text())
    if report["build"]["sources"] != source_fingerprints():
        raise RuntimeError("Changed build sources")
    if report["installedArtifactSha256"] != report["build"]["artifactSha256"]:
        raise RuntimeError("Installed APK differs")
    failures = classify(report, expect_retained_outcomes=args.expect_retained_outcomes)
    for issue in failures:
        print(issue)
    print(f"{args.report.stem}: {len(failures)} failures. Guarded frames: {describe(report)}")
    raise SystemExit(int(bool(failures)))


if __name__ == "__main__":
    main()
