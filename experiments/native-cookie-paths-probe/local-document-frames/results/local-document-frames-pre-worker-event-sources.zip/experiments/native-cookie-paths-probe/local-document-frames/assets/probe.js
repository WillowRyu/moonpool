async function frameDocument(name) {
  const origin = window.origin;
  const protocol = window.location.protocol;
  parent.postMessage({ type: 'ready', name, origin, protocol }, '*');
  if (name === 'data') {
    return;
  }

  const script = new URL('/worker.js', origin).href;
  const violations = [];
  document.addEventListener('securitypolicyviolation', (event) => {
    if (event.effectiveDirective === 'worker-src') {
      violations.push({
        directive: event.effectiveDirective,
        disposition: event.disposition,
        blockedURI: event.blockedURI,
        trusted: event.isTrusted,
      });
    }
  });
  const outcome = await new Promise((resolve) => {
    let worker;
    try {
      worker = new Worker(script);
    } catch {
      resolve('rejected');
      return;
    }
    function finish(result) {
      clearTimeout(deadline);
      worker.terminate();
      resolve(result);
    }
    const deadline = setTimeout(() => finish('timeout'), 4500);
    worker.addEventListener('message', (message) =>
      finish(message.data === 'local-frame-worker' ? 'message' : 'unexpected-message'),
    );
    worker.addEventListener('error', () => finish('rejected'));
  });
  await new Promise((resolve) => setTimeout(resolve, 200));
  parent.postMessage({ type: 'worker-result', name, outcome, violations }, '*');
}

(async () => {
  if (window !== window.parent) {
    await frameDocument('same');
    return;
  }

  try {
    const kind = window.location.pathname.slice('/entry/'.length);
    const html = `<!doctype html><meta charset=utf-8><script>(${frameDocument.toString()})(${JSON.stringify(kind)});</script>`;
    const url = {
      same: () => `${window.origin}/same-frame`,
      blob: () => URL.createObjectURL(new Blob([html], { type: 'text/html' })),
      data: () => `data:text/html;charset=utf-8,${encodeURIComponent(html)}`,
    }[kind]();
    const frame = document.createElement('iframe');
    const state = {
      parentUrl: window.location.href,
      trace: [],
      starts: [],
      workers: [],
      frameViolations: [],
    };

    function read(event) {
      const data = event.data;
      if (event.source !== frame.contentWindow || data?.name !== kind) {
        return;
      }
      if (data.type === 'ready') {
        state.starts.push({
          name: data.name,
          origin: data.origin,
          protocol: data.protocol,
          messageOrigin: event.origin,
        });
        state.trace.push('ready');
      }
      if (data.type === 'worker-result') {
        state.workers.push({
          outcome: data.outcome,
          violations: data.violations,
          messageOrigin: event.origin,
        });
        state.trace.push('worker-result');
      }
    }

    function recordViolation(event) {
      if (event.effectiveDirective === 'frame-src') {
        const scheme = event.blockedURI ? event.blockedURI.split(':', 1)[0] : null;
        state.frameViolations.push({
          directive: event.effectiveDirective,
          disposition: event.disposition,
          scheme,
          trusted: event.isTrusted,
        });
        state.trace.push('frame-violation');
      }
    }

    window.addEventListener('message', read);
    document.addEventListener('securitypolicyviolation', recordViolation);
    frame.src = url;
    state.trace.push('attach');
    document.body.append(frame);
    await new Promise((resolve) => setTimeout(resolve, 6500));
    window.removeEventListener('message', read);
    document.removeEventListener('securitypolicyviolation', recordViolation);
    frame.remove();
    state.trace.push('detach');
    if (kind === 'blob') {
      URL.revokeObjectURL(url);
    }
    window.localFramesResult = state;
  } catch (error) {
    window.localFramesResult = { error: String(error) };
  }
})();
