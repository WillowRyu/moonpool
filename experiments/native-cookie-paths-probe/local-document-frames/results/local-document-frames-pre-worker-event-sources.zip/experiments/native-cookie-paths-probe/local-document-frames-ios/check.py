"""Verify the frame and worker evidence collected by the WebKit fixture."""

import argparse
from collections import Counter
import hashlib
import json
import os
from pathlib import Path
import re
from uuid import UUID

ROOT = Path(__file__).resolve().parent
ASSETS = ROOT.parent / "local-document-frames/assets"
GATE = ROOT.parent.parent / "native-cookie-admission-probe/ios/AdmissionGate.swift"
PRESENCE = ROOT.parent / "profile-retirement-ios/CookiePresence.swift"
POLICY = "default-src 'none'; script-src 'self' 'unsafe-inline'; frame-src 'self'; worker-src 'none'; base-uri 'none'"
KINDS = ("same", "blob", "data")
MODES = ("control", "guarded")
EMPTY_COOKIES = {"policyDisallowed": True, "records": False, "cookies": False}


def frame_refusal(page, kind):
    events = page.get("frameViolations", [])
    if len(events) != 1:
        return False
    event = events[0]
    return (
        page.get("starts") == []
        and page.get("workers") == []
        and page.get("trace") == ["attach", "frame-violation", "detach"]
        and event.get("directive") == "frame-src"
        and event.get("disposition") == "enforce"
        and event.get("trusted") is True
        and "scheme" in event
        and event["scheme"] in (kind, None)
    )


def frame_failures(frame, origin, mode, kind, store):
    page = frame.get("page", {})
    entry = f"/entry/{kind}"
    if frame.get("parentUrl") != origin + entry or page.get("parentUrl") != origin + entry or frame.get("store") != store:
        return ["parent document or store binding differs"]

    failures = []
    documents = [entry, "/same-frame"] if kind == "same" else [entry]
    policy = POLICY if mode == "guarded" else ""
    if frame.get("policies") != dict.fromkeys(documents, policy):
        failures.append("document response policies differ")
    requests = Counter(frame.get("requests", []))
    worker_receipts = requests.pop("/worker.js", 0)
    if requests != Counter(documents + ["/probe.js"] * len(documents)):
        failures.append("document or script receipts differ")

    if mode == "guarded" and kind == "data":
        if not frame_refusal(page, kind) or worker_receipts:
            failures.append("no attributable enforcing frame refusal")
        return failures

    child_origin = "null" if kind == "data" else origin
    protocol = "moonpool:" if kind == "same" else kind + ":"
    ready = {"name": kind, "protocol": protocol, "origin": child_origin, "messageOrigin": child_origin}
    if page.get("starts") != [ready] or page.get("frameViolations") != []:
        failures.append("the frame start, document origin or enforcing events differ")

    workers = page.get("workers", [])
    trace = ["attach", "ready"]
    if kind == "data":
        if workers or worker_receipts:
            failures.append("the data frame made an unexpected worker attempt")
    else:
        trace.append("worker-result")
        if len(workers) != 1 or not worker_evidence(workers[0], origin, mode, receipts=worker_receipts):
            failures.append("the worker outcome lacks matching evidence")
    if page.get("trace") != trace + ["detach"]:
        failures.append("the frame observation sequence differs")
    return failures


def classify(report):
    run = report.get("run", "")
    if not re.fullmatch(r"ios-[a-z0-9-]{1,24}", run):
        return ["invalid native run tag"]
    if (report.get("complete") is not True or report.get("platform") != "ios"
            or report.get("initializedWebKit") is not True or not report.get("release")):
        return [report.get("error", "native collection did not complete")]
    samples = report.get("samples", {})
    if set(samples) != set(MODES):
        return ["both identified stores are required"]

    failures = []
    stores = set()
    for mode in MODES:
        sample = samples[mode]
        store = sample.get("store", "")
        try:
            identifier = UUID(store)
        except ValueError:
            failures.append(f"{mode}: missing identified store")
            continue
        if identifier.version != 4 or identifier in stores or sample.get("persistent") is not True:
            failures.append(f"{mode}: the fixture needs a distinct persistent store")
        stores.add(identifier)
        cookies = sample.get("cookies", {})
        if set(cookies) != set(EMPTY_COOKIES) or any(cookies[key] is not value for key, value in EMPTY_COOKIES.items()):
            failures.append(f"{mode}: empty, disallowed cookie evidence is required")

        origin = f"moonpool://com.example.localframes.{run}.{mode}"
        frames = sample.get("frames", {})
        if set(frames) != set(KINDS):
            failures.append(f"{mode}: frame cases differ")
            continue
        for kind in KINDS:
            failures.extend(f"{mode}/{kind}: {failure}"
                            for failure in frame_failures(frames[kind], origin, mode, kind, store))
    return failures


def worker_evidence(worker, origin, mode, *, receipts):
    if worker.get("messageOrigin") != origin:
        return False
    outcome = worker.get("outcome")
    events = worker.get("violations")
    if mode == "control":
        return outcome == "message" and receipts == 1 and events == []

    if outcome != "rejected" or receipts != 0 or not isinstance(events, list) or len(events) != 1:
        return False
    event = events[0]
    return (
        event.get("directive") == "worker-src"
        and event.get("disposition") == "enforce"
        and event.get("trusted") is True
        and event.get("blockedURI") == origin + "/worker.js"
    )


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def source_fingerprints():
    paths = (ROOT / "Probe.swift", ROOT / "check.py", ROOT / "run_probe.py", ROOT.parent / "runner.py",
             GATE, PRESENCE, ASSETS / "probe.js", ASSETS / "worker.js")
    return {Path(os.path.relpath(path, ROOT)).as_posix(): sha(path) for path in sorted(paths)}


def verify_report(report):
    build = report["build"]
    if build["sources"] != source_fingerprints():
        raise RuntimeError("Changed build sources")
    if report["installedArtifactSha256"] != build["artifactSha256"]:
        raise RuntimeError("Installed app differs")
    return classify(report)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("report", type=Path)
    args = parser.parse_args()
    failures = verify_report(json.loads(args.report.read_text()))
    for failure in failures:
        print(failure)
    print(f"{args.report.stem}: {len(failures)} failures")
    raise SystemExit(int(bool(failures)))


if __name__ == "__main__":
    main()
