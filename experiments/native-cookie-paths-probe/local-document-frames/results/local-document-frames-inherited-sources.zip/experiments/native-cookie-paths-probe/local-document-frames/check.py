"""Validate Android observations of local generated frame documents."""

import argparse
from collections import Counter
import hashlib
import json
import os
from pathlib import Path
from zipfile import ZipFile

ROOT = Path(__file__).resolve().parent
POLICY = "default-src 'none'; script-src 'self' 'unsafe-inline'; frame-src 'self'; worker-src 'none'; base-uri 'none'"
KINDS = ("same", "blob", "data")
INHERITED_URLS = {"blank": "about:blank", "srcdoc": "about:srcdoc"}
DOCUMENT_SETS = {"local": KINDS, "inherited": tuple(INHERITED_URLS)}
FRAME_SOURCES = ("self", "origin")


def document_started(origin, kind, starts):
    expected_origin = "null" if kind == "data" else origin
    expected = {"name": kind, "protocol": ("https" if kind == "same" else kind) + ":",
                "origin": expected_origin, "messageOrigin": expected_origin}
    if kind in INHERITED_URLS:
        if len(starts) != 1 or not isinstance(starts[0], dict):
            return False
        secure = starts[0].get("secureContext")
        service_worker = starts[0].get("serviceWorkerRegistration")
        if type(secure) is not bool or type(service_worker) is not bool:
            return False
        expected.update(protocol="about:", url=INHERITED_URLS[kind], secureContext=secure,
                        serviceWorkerRegistration=service_worker)
    return starts == [expected]


def observation_failures(origin, mode, kind, page):
    failures = []
    starts = page.get("starts")
    workers = page.get("workers")
    worker_violations = page.get("workerViolations")
    violations = page.get("frameViolations")
    trace = page.get("trace")
    if not all(isinstance(values, list) for values in (starts, workers, worker_violations, violations, trace)):
        return ["the frame observation is incomplete"]
    if not starts:
        if mode == "control" or kind == "same" or kind in INHERITED_URLS:
            failures.append("the positive document control did not report")
        expected = {"directive": "frame-src", "disposition": "enforce", "scheme": kind, "trusted": True}
        observed = violations == [expected] or (kind == "data" and violations == [dict(expected, scheme=None)])
        if not observed or violations[0]["trusted"] is not True:
            failures.append("an enforcing frame-src event was not observed")
        if workers or worker_violations or trace != ["attach", "frame-violation", "detach"]:
            failures.append("the blocked frame observation sequence differs")
        return failures

    if mode == "guarded" and kind == "data":
        failures.append("the opaque document executed")
    if not document_started(origin, kind, starts):
        failures.append("the executed document's URL scheme or origin differs")
    if violations:
        failures.append("the executed document also reports a frame refusal")
    worker_signals = []
    if kind == "data":
        if workers or worker_violations:
            failures.append("the opaque document reported an unexpected worker")
    else:
        worker_signals.append("worker-result")
        expected_worker = {"messageOrigin": origin, "outcome": "message"}
        expected_violations = []
        if mode == "guarded":
            expected_worker["outcome"] = "rejected"
            expected_violations.append({"directive": "worker-src", "disposition": "enforce", "trusted": True,
                                        "blockedURI": origin + "/worker.js", "messageOrigin": origin})
            worker_signals.append("worker-violation")
        if (workers != [expected_worker] or worker_violations != expected_violations
                or any(event["trusted"] is not True for event in worker_violations)):
            failures.append("the executed document's worker result or violation differs")
    if (trace[:2] != ["attach", "ready"] or trace[-1:] != ["detach"]
            or Counter(trace[2:-1]) != Counter(worker_signals)):
        failures.append("the frame observation sequence differs")
    return failures


def classify(report, *, expect_retained_outcomes=False):
    failures = []
    run = report["run"]
    frame_source = report.get("frameSource", "self")
    if frame_source not in FRAME_SOURCES:
        return ["invalid frame source"]
    document_set = report.get("documentSet", "local")
    if not isinstance(document_set, str) or document_set not in DOCUMENT_SETS:
        return ["invalid document set"]
    kinds = DOCUMENT_SETS[document_set]
    if report.get("complete") is not True or not all(report.get(key) for key in ("sdk", "release", "provider")):
        failures.append("native collection did not complete")
    samples = report.get("samples", {})
    if set(samples) != {"control", "guarded"}:
        failures.append("both fresh profiles are required")
    for mode in ("control", "guarded"):
        sample = samples.get(mode, {})
        origin = f"https://mp-{run}-{mode}.invalid"
        policy = ""
        if mode == "guarded":
            policy = POLICY.replace("frame-src 'self'", f"frame-src {origin}") if frame_source == "origin" else POLICY
        if (sample.get("profile") != f"local-document-frames-{run}-{mode}" or sample.get("created") is not True
                or sample.get("cookieDeny") is not True):
            failures.append(f"{mode}: selected profile or cookie deny differs")
        frames = sample.get("frames", {})
        if set(frames) != set(kinds):
            failures.append(f"{mode}: frame samples differ")
        worker_receipts = {}
        for kind in kinds:
            frame = frames.get(kind, {})
            page = frame.get("page", {})
            entry = f"/entry/{kind}"
            url = origin + entry
            if frame.get("parentUrl") != url or page.get("parentUrl") != url:
                failures.append(f"{mode}/{kind}: the separate parent document differs")
            if frame.get("policy") != policy:
                failures.append(f"{mode}/{kind}: parent response policy differs")
            requests = frame.get("requests", [])
            expected = {entry, "/probe.js"}
            if kind == "same":
                expected.add("/same-frame")
            worker_receipts[kind] = requests.count("/worker.js")
            allowed = expected | {"/worker.js"} if mode == "control" and kind != "data" else expected
            if (not expected <= set(requests) <= allowed or requests.count(entry) != 1
                    or requests.count("/same-frame") != int(kind == "same")
                    or (kind in INHERITED_URLS and requests.count("/probe.js") != 1)):
                failures.append(f"{mode}/{kind}: loader requests differ")
            failures.extend(f"{mode}/{kind}: {issue}" for issue in observation_failures(origin, mode, kind, page))
            if expect_retained_outcomes and mode == "guarded" and kind == "blob" and page.get("starts"):
                failures.append("guarded/blob: retained frame refusal differs")
        if mode == "control":
            if not sum(worker_receipts.values()):
                failures.append("control: no worker script reached the native loader")
            if expect_retained_outcomes and worker_receipts != {kind: int(kind != "data") for kind in kinds}:
                failures.append("control: retained worker receipt counts differ")
    return failures


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def source_fingerprints(source_archive=None):
    wrapper = ROOT.parent.parent / "android-origin-probe"
    android = ROOT / "android"
    files = [
        ROOT / "check.py", ROOT / "run_probe.py", ROOT.parent / "runner.py",
        wrapper / "gradlew", wrapper / "gradle/wrapper/gradle-wrapper.jar",
        wrapper / "gradle/wrapper/gradle-wrapper.properties",
        android / "settings.gradle", android / "build.gradle", android / "gradle.properties",
        android / "app/build.gradle", android / "app/src/main/AndroidManifest.xml",
    ]
    files.extend((ROOT / "assets").glob("*.js"))
    files.extend((android / "app/src/main/java").rglob("*.java"))
    if source_archive is not None:
        with ZipFile(source_archive) as archive:
            names = archive.namelist()
            if len(names) != len(set(names)):
                raise ValueError("Duplicate archived source")
            return {Path(os.path.relpath(path, ROOT)).as_posix():
                    hashlib.sha256(archive.read(path.relative_to(ROOT.parents[2]).as_posix())).hexdigest()
                    for path in sorted(files)}
    return {Path(os.path.relpath(path, ROOT)).as_posix(): sha(path) for path in sorted(files)}


def describe(report):
    frames = report.get("samples", {}).get("guarded", {}).get("frames", {})
    return ", ".join(f"{kind}: {'executed' if frames[kind].get('page', {}).get('starts') else 'no document'}"
                     for kind in (*KINDS, *INHERITED_URLS) if kind in frames)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("report", type=Path)
    parser.add_argument("--expect-retained-outcomes", action="store_true",
                        help="Require blob refusal and one loader worker receipt per control worker frame")
    parser.add_argument("--source-archive", type=Path, help="Verify the report against its archived build inputs")
    parser.add_argument("--expect-frame-source", choices=FRAME_SOURCES)
    parser.add_argument("--expect-document-set", choices=DOCUMENT_SETS)
    args = parser.parse_args()
    report = json.loads(args.report.read_text())
    if report["build"]["sources"] != source_fingerprints(args.source_archive):
        raise RuntimeError("Changed build sources")
    if report["installedArtifactSha256"] != report["build"]["artifactSha256"]:
        raise RuntimeError("Installed APK differs")
    failures = classify(report, expect_retained_outcomes=args.expect_retained_outcomes)
    if args.expect_frame_source is not None and report.get("frameSource", "self") != args.expect_frame_source:
        failures.append("frame source differs from expectation")
    if args.expect_document_set is not None and report.get("documentSet", "local") != args.expect_document_set:
        failures.append("document set differs from expectation")
    for issue in failures:
        print(issue)
    print(f"{args.report.stem}: {len(failures)} failures. Guarded frames: {describe(report)}")
    raise SystemExit(int(bool(failures)))


if __name__ == "__main__":
    main()
