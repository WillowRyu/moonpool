"""Validate Android observations of local generated frame documents."""

import argparse
import hashlib
import json
import os
from pathlib import Path

ROOT = Path(__file__).resolve().parent
POLICY = "default-src 'none'; script-src 'self' 'unsafe-inline'; frame-src 'self'; worker-src 'none'; base-uri 'none'"
KINDS = ("same", "blob", "data")


def document_identity(origin, kind):
    expected_origin = "null" if kind == "data" else origin
    return {"name": kind, "protocol": ("https" if kind == "same" else kind) + ":",
            "origin": expected_origin, "messageOrigin": expected_origin}


def protected_frame_failures(origin, kind, sample):
    document = sample.get("document")
    if document is None:
        if kind == "same":
            return ["the same-origin frame did not execute"]
        expected = {"directive": "frame-src", "disposition": "enforce", "scheme": kind}
        event = sample.get("frameViolation")
        if event == expected or (kind == "data" and event == dict(expected, scheme=None)):
            return []
        return ["an enforcing frame-src event was not observed"]
    if kind == "data":
        return ["the opaque document executed"]
    failures = []
    if any(document.get(key) != value for key, value in document_identity(origin, kind).items()):
        failures.append("the executed document's URL scheme or origin differs")
    expected_worker = {
        "outcome": "rejected",
        "violation": {"directive": "worker-src", "disposition": "enforce", "blockedURI": origin + "/worker.js"},
    }
    if document.get("worker") != expected_worker:
        failures.append("the executed document lacks an enforcing worker-src event")
    if sample.get("frameViolation") is not None:
        failures.append("the executed document also reports a frame refusal")
    return failures


def classify(report):
    failures = []
    run = report["run"]
    if report.get("complete") is not True or not all(report.get(key) for key in ("sdk", "release", "provider")):
        failures.append("native collection did not complete")
    samples = report.get("samples", {})
    if set(samples) != {"control", "guarded"}:
        failures.append("both fresh profiles are required")
    for mode in ("control", "guarded"):
        sample = samples.get(mode, {})
        origin = f"https://mp-{run}-{mode}.invalid"
        if (sample.get("profile") != f"local-document-frames-{run}-{mode}" or sample.get("created") is not True
                or sample.get("cookieDeny") is not True
                or sample.get("policy") != (POLICY if mode == "guarded" else "")):
            failures.append(f"{mode}: profile or response policy differs")
        requests = sample.get("requests", [])
        expected = {"/entry", "/same-frame", "/probe.js"}
        if mode == "control":
            expected.add("/worker.js")
        if set(requests) != expected or requests.count("/entry") != 1 or requests.count("/same-frame") != 1:
            failures.append(f"{mode}: loader requests differ")
        page = sample.get("page", {})
        if page.get("trace") != [f"{kind}:{point}" for kind in KINDS for point in ("attach", "detach")]:
            failures.append(f"{mode}: frame lifetimes were not isolated")
        observations = page.get("frames", {})
        if set(observations) != set(KINDS):
            failures.append(f"{mode}: frame samples differ")
        for kind in KINDS:
            observation = observations.get(kind, {})
            if mode == "guarded":
                issues = protected_frame_failures(origin, kind, observation)
                failures.extend(f"{mode}/{kind}: {issue}" for issue in issues)
                continue
            document = observation.get("document") or {}
            identity = document_identity(origin, kind)
            if any(document.get(key) != value for key, value in identity.items()):
                failures.append(f"{mode}/{kind}: the positive document control did not report")
            worker = None if kind == "data" else {"outcome": "message", "violation": None}
            if "worker" not in document or document.get("worker") != worker or observation.get("frameViolation") is not None:
                failures.append(f"{mode}/{kind}: the positive control outcome differs")
    return failures


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def source_fingerprints():
    wrapper = ROOT.parent.parent / "android-origin-probe"
    android = ROOT / "android"
    files = [
        ROOT / "check.py", ROOT / "run_probe.py", ROOT.parent / "runner.py",
        wrapper / "gradlew", wrapper / "gradle/wrapper/gradle-wrapper.jar",
        wrapper / "gradle/wrapper/gradle-wrapper.properties",
        android / "settings.gradle", android / "build.gradle", android / "gradle.properties",
        android / "app/build.gradle", android / "app/src/main/AndroidManifest.xml",
    ]
    files.extend((ROOT / "assets").glob("*.js"))
    files.extend((android / "app/src/main/java").rglob("*.java"))
    return {Path(os.path.relpath(path, ROOT)).as_posix(): sha(path) for path in sorted(files)}


def describe(report):
    frames = report.get("samples", {}).get("guarded", {}).get("page", {}).get("frames", {})
    return ", ".join(f"{kind}: {'executed' if frames[kind].get('document') else 'no document'}"
                     for kind in KINDS if kind in frames)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("report", type=Path)
    args = parser.parse_args()
    report = json.loads(args.report.read_text())
    if report["build"]["sources"] != source_fingerprints():
        raise RuntimeError("Changed build sources")
    if report["installedArtifactSha256"] != report["build"]["artifactSha256"]:
        raise RuntimeError("Installed APK differs")
    failures = classify(report)
    for issue in failures:
        print(issue)
    print(f"{args.report.stem}: {len(failures)} failures. Guarded frames: {describe(report)}")
    raise SystemExit(int(bool(failures)))


if __name__ == "__main__":
    main()
