async function frameDocument(name) {
  const origin = window.origin;
  const protocol = window.location.protocol;
  const report = { name, origin, protocol, worker: null };
  if (name === 'data') {
    parent.postMessage(report, '*');
    return;
  }

  let violation = null;
  const script = new URL('/worker.js', origin).href;
  document.addEventListener('securitypolicyviolation', (event) => {
    if (event.effectiveDirective === 'worker-src' && event.blockedURI === script) {
      violation = {
        directive: event.effectiveDirective,
        disposition: event.disposition,
        blockedURI: event.blockedURI,
      };
    }
  });
  const outcome = await new Promise((resolve) => {
    let worker;
    try {
      worker = new Worker(script);
    } catch {
      resolve('rejected');
      return;
    }
    function finish(result) {
      clearTimeout(deadline);
      worker.terminate();
      resolve(result);
    }
    const deadline = setTimeout(() => finish('timeout'), 5500);
    worker.addEventListener('message', (message) =>
      finish(message.data === 'local-frame-worker' ? 'message' : 'unexpected-message'),
    );
    worker.addEventListener('error', () => finish('rejected'));
  });
  await new Promise((resolve) => setTimeout(resolve, 200));
  parent.postMessage({ ...report, worker: { outcome, violation } }, origin);
}

(async () => {
  if (window !== window.parent) {
    await frameDocument('same');
    return;
  }

  function sampleFrame(kind, trace) {
    const html = `<!doctype html><meta charset=utf-8><script>(${frameDocument.toString()})(${JSON.stringify(kind)});</script>`;
    const url = {
      same: () => `${window.origin}/same-frame`,
      blob: () => URL.createObjectURL(new Blob([html], { type: 'text/html' })),
      data: () => `data:text/html;charset=utf-8,${encodeURIComponent(html)}`,
    }[kind]();
    return new Promise((resolve) => {
      const frame = document.createElement('iframe');
      const state = { document: null, frameViolation: null };
      let drain;
      const deadline = setTimeout(finish, 8500);
      function finish() {
        clearTimeout(deadline);
        clearTimeout(drain);
        window.removeEventListener('message', read);
        document.removeEventListener('securitypolicyviolation', recordViolation);
        frame.remove();
        trace.push(`${kind}:detach`);
        if (kind === 'blob') {
          URL.revokeObjectURL(url);
        }
        resolve(state);
      }
      function settle() {
        drain ??= setTimeout(finish, 200);
      }
      function read(event) {
        if (event.source === frame.contentWindow && event.data?.name === kind) {
          state.document = { ...event.data, messageOrigin: event.origin };
          settle();
        }
      }
      function recordViolation(event) {
        if (event.effectiveDirective === 'frame-src') {
          const scheme = event.blockedURI ? event.blockedURI.split(':', 1)[0] : null;
          state.frameViolation = {
            directive: event.effectiveDirective,
            disposition: event.disposition,
            scheme,
          };
          settle();
        }
      }
      window.addEventListener('message', read);
      document.addEventListener('securitypolicyviolation', recordViolation);
      frame.src = url;
      document.body.append(frame);
      trace.push(`${kind}:attach`);
    });
  }

  try {
    const frames = {};
    const trace = [];
    for (const kind of ['same', 'blob', 'data']) {
      frames[kind] = await sampleFrame(kind, trace);
    }
    window.localFramesResult = { frames, trace };
  } catch (error) {
    window.localFramesResult = { error: String(error) };
  }
})();
